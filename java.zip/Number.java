import java.util.Scanner;
class number{
public static void main(String[]args)
{
int a;
int b;
int c;
int d;
Scanner s=new Scanner(System.in);
System.out.println("enter the value");
 a=s.nextInt();
b=s.nextInt();
c=s.nextInt();
d=s.nextInt();
if(a==13)
{
System.out.println(c+d);}
else if(b==13)
{
System.out.println(d+a);
}
else if (c==13)
{
System.out.println(a+b);
}
else if(d==13)
{
System.out.println(b+c);
}else
{System.out.println(a+b+c+d);
}
}
}

