import java.util.Scanner;
public class sumofdigit{
private static Scanner sc;
public static void main(String[]args)
{int n;
int r;
int sum=0;
sc=new Scanner(System.in);
System.out.println("enter the number");
n = sc.nextInt();
for(sum=0;n>0;)
{r=n%10;
n=n/10;
sum=sum+r;
}
System.out.format("sum of digit = %d",sum);
}}