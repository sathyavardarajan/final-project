import java.util.*;
class duplicatecount
{public static void main(String[] args)
{
String name="engineering";
int count=0;

System.out.println("Duplicate letters are:");
for(int i=1;i<name.length();i++)
{for(int j=0;j<name.length();j++)
{
if(name.charAt(i) == name.charAt(j))
{ count++;}}
System.out.println(name.charAt(i)+"--"+count);
String d=String.valueOf(name.charAt(i)).trim();
name=name.replaceAll(d,"");
count=0;

}}}