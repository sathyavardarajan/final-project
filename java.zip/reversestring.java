import java.util.*;
class reversestring
{
public static void main(String args[])
{
String r,reverse="";
Scanner in = new Scanner(System.in);
System.out.println("enter the string:");
r = in.nextLine();
int length = r.length();
for( int i = length - 1;i >=0 ; i--)
reverse=reverse+r.charAt(i);

System.out.println("RESULT:"+reverse);
}}