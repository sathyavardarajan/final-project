public class add
{public static void main (String[]args)
{int n=5;
int sum;

for(int i=1;i<=20;++i)
{
sum=n*i;

System.out.println(sum);

}}}