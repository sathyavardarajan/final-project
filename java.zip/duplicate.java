import java.util.*;
class duplicate
{public static void main(String[] args)
{
String name="apple";
String dup;
int count=0;
char [] input=name.toCharArray();
System.out.println("Duplicate letters are:");
for(int i=0;i<name.length();i++)
{for(int j=i+1;j<name.length();j++)
{
if(input[i] == input[j])
{
System.out.print(input[j]);
count++;
break;
}}}}}