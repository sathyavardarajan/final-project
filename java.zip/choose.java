import java.util.*;
class choose
{public static void main(String[]agrs)
{int a=10;
int b=2;
int output;
Scanner s = new Scanner(System.in);
System.out.println("Enter the operator(+,-,*,/):");
char operator= s.next().charAt(0);

switch(operator)
{case '*':System.out.println(output=a*b);
break;
case '%':System.out.println(output=a%b);
break;
case '+':System.out.println(output=a+b);
break; 
case '-':System.out.println(output=a-b);
break;
case '/':System.out.println(output=a/b);
break;

}}}