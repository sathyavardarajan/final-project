import java.util.Scanner;
public class reverse
{
public static void main(String[]args)
{
int r=0,j=0;
Scanner s=new Scanner(System.in);
System.out.println("enter the number");
j=s.nextInt();
while(j != 0)
{r=r*10;
r=r+j%10;
j=j/10;
}
System.out.println("results:"+r);

}}

